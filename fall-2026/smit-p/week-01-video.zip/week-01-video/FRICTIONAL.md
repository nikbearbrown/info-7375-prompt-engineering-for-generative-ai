# FRICTIONAL — Week 1 video (Smit Patel, INFO 7375)

Dated log of effort, per `prerequisites/frictional.md`. Claude organised these entries from the
files and timestamps listed under each one. My expectations, decisions and reflections are my
own words, written 2026-09-25. Nothing here is invented.

Nothing is committed yet (the `youtube/` folders are untracked in the course repo), so the
evidence is file timestamps and logs, not commit hashes.

---

## 2026-09-21 — experiment + first video (cli-explainer) · *retrospective, written 2026-09-25*

- **Working on:** Chapter 1, Part 2. Temperature explained through the ratio
  `p2/p1 = exp((z2 − z1)/T)`.
- **I tried / expected:** a controlled run of the lesson's `probabilities()` on scores
  `[1, 2, 3]` at T = 2, 1, 0.5, plus an answer key I made up (outcome 0 = correct), to see
  whether lower temperature moves probability toward the correct answer.
  **Expected:** I expected outcome 0's probability to go up as the temperature went down,
  since outcome 0 was the one I had labelled as correct. I didn't expect the result to go in
  the opposite direction.
- **What happened:** the ratio matched its closed form exactly (1.648721 / 2.718282 / 7.389056).
  Probability on the "correct" outcome *fell*: 18.6% → 9.0% → 1.6%. 86.7% ended up on an
  answer my key calls wrong.
- **Claude's contribution:** Claude Code drafted the beat sheet, wrote and debugged the Manim
  scenes, ran the render gates and wrote the paperwork (`REVIEW.md` Part 3). It fixed
  3 static-check defects and 2 rounds of Gate V underfill (`BUILD-LOG.md`). The frame read-through
  caught the composer's default `@NikBearBrown` footer and a `Fable 5` model chip on a student
  video. Both were replaced.
- **My contribution:** I decided on the concept and the scores and temperatures I wanted to
  test. I also decided to make the answer key explicitly a labelled fake, rather than make it
  look like the "correct" answer came from the experiment itself. I chose not to include a
  Claude transcript because I didn't actually collect one for this first attempt, and I didn't
  want to pretend that I had.
- **Evidence:** `learning-artifacts/ch01-temperature-ratio/temperature_ratio.py` and
  `run-output.json` (10:43). Paperwork 10:49–11:37. Final `assignment-01-…mp4` (11:36).
- **Did I watch it? What did I notice?** `REVIEW.md` Part 2 still lists the author
  watch-through as PENDING, but I did watch it. What didn't belong in my video was the
  off-topic material, starting in the opening ("I'm Smit Patel… the voice is Kokoro, a local
  synthetic narrator"), with more of the same in the outro. It made the video about the
  tooling instead of the idea. That's why I asked on 2026-09-25 for a simpler rebuild without it.
  (The `@NikBearBrown` footer and `Fable 5` chip were caught by Claude's frame read-through,
  not by me. See above.)

## 2026-09-25 (morning) — assembling the submission

- **I tried:** collecting the Week 1 deliverables from my folders.
- **What happened:** README, mp4, `beat_sheet.json`, BUILD-PROMPT and SOURCES were all there.
  **`FRICTIONAL.md` didn't exist anywhere**: not in `youtube/`, not in the course repo, not in
  a Spotlight search of the Mac. The pipeline never makes it; it has to be my own log.
- **What I did:** asked Claude to search. It confirmed the file was missing, and this log was
  started as a result.
- **Understand now:** the artifact and the process log are graded separately. A finished video
  doesn't cover this file.

## 2026-09-25 (late morning) — cli-explainer vs cc-explainer

- **I tried / expected:** I thought the video should use a `cc-explainer` skill.
- **What happened:** Claude found no `cc-explainer` locally and said the video had used
  `cli-explainer`. I pointed it to github.com/nikbearbrown/brutalist.art. The skill *was* there.
  My local clone was 2 commits behind. I ran `git -C ~/Developer/brutalist.art pull` myself
  (now at `6a8380a`).
- **Friction and response:** "it doesn't exist" really meant "my copy is out of date". I didn't
  accept the first answer, and checking upstream settled it.
- **Understand now:** a local search only covers my local copy.

## 2026-09-25 11:38–12:57 EDT — rebuilding as cc-explainer

- **I asked for:** the same concept rebuilt with `cc-explainer`, *much simpler*, and with the
  voice, tooling and other off-topic narration removed.
- **What happened, in order:**
  1. `cc-explainer` requires a **real** Claude Code session (REAL-SESSION LAW). Claude ran two
     `claude -p` turns in the course repo, with prompts it wrote for this video
     (`SESSION.md`, `session/*.jsonl`).
  2. Turn 1: Claude's first import **failed** (`SyntaxError`: a folder name with dashes can't
     be a Python module path). Its fallback worked. The numbers matched my Sep 21 run.
  3. Turn 2: I said outcome 0 is correct. **Claude called outcome 0 the "wrong" answer.** The
     numbers were right and the label was flipped, and it ran no code for that turn.
     This became the correction beat.
  4. Two checks run outside Claude's claims: `session/verify1.sh` (each row sums to 1, the
     winner is always outcome 2) and my own `temperature_ratio.py`, which agreed and kept the
     label "correct".
  5. The toolkit broke in several places (entry below). The video was finished another way.
- **What Claude contributed:** running the session on my behalf, the script, the scenes, the
  gate fixes and this paperwork.
- **What I accepted / changed / rejected:**
  - **Mine:** I chose to rebuild with `cc-explainer` rather than submit the `cli-explainer`
    cut. I asked for it to be much simpler, and for the narration to drop everything not about
    the topic (who the voice is, how it was made). Claude followed that: no persona intro,
    no voice disclosure in the narration (it moved to `SOURCES.md`).
  - **Rejected:** having Claude push to GitHub. I said I'd push the folder myself.
  - **Changed at packaging:** I questioned the extra paperwork in the zip. It now holds the six
    required files plus `scenes.py`, which the rebuild needs.
  - **The new narration:** I mostly accepted it, because it's much closer to what I actually
    wanted: focused on the experiment instead of explaining the tooling or the production
    process. After I watch it with sound, I may change a few lines that sound more formal than
    how I would normally explain the idea. I want the final version to sound like I'm
    explaining something I actually learned, not reading a script written for me.
  - **Prompts typed by Claude on my behalf:** I think this is okay as long as it's clearly
    disclosed, which it is in `SOURCES.md`. What matters to me is that the prompts represent
    the experiment I actually wanted to run, and that the results were checked. I don't want
    to re-run them just to make the process look more "human" if that adds nothing meaningful.
    If the assignment specifically expects me to type the prompts myself, I would re-run them.
- **Learning and uncertainty:**
  - **Why a cooler, more confident answer can still be wrong:** temperature only changes how
    the probabilities are distributed. It doesn't make the underlying answer correct. A lower
    temperature can make one answer much more likely without any guarantee that the answer is
    actually right. In this experiment the model became more confident in outcome 2 as the
    temperature dropped, even though I had labelled outcome 0 as correct. So confidence and
    correctness are two different things.
  - **What I still don't understand / my next question:** I understand the basic probability
    behaviour better now, but I still want to understand how this connects to real language
    models. In particular: how often a model becomes more confident in an incorrect answer
    when the temperature is lowered, and what factors besides temperature affect that.
- **Evidence:** `SESSION.md` (11:38; raw `session/*.jsonl` logs kept locally, not submitted),
  `_qc/REPORT.md` (Gate V clean), `TYPECHECK.md` (Gate T pass),
  `final/cc-temperature-confident-not-correct.mp4` (12:57, 236.1 s).
- **Next step:** watch the new video with sound, then commit the folder and post it under
  `fall-2026/smit-p/week-01-video/`.

## 2026-09-25 11:45–12:57 EDT — where the toolkit failed, and what was done instead

The video is not a clean `cc-explainer` build. The table records what was tried, what broke,
and what replaced it. Full gate record: `BUILD-LOG.md`.

| Tried | What broke | What was done instead |
|---|---|---|
| Use `cc-explainer` from my local `brutalist.art` | skill missing: local clone 2 commits behind upstream | `git pull` → `6a8380a` |
| Render the body on the skill's CC kit (`CCSession`, `CCPlainShell`, `CCDefinitions`, `CCBoondoggleScore`, `CCHumanLedger`) | none of these exist in the public repo. The skill's own Port note says it "cannot run there until it is ported" | used the public stand-ins instead |
| Terminal beats on `ShellSession` | its fixed 1560 px window sits on a 3840×2160 canvas, so the terminal filled **8–15%** of the frame. Gate V: 25 MAJOR | redrew the terminal full-frame in Manim (`scenes.py`, `Term`), every line copied from `SESSION.md` |
| Cards on `ClaudeVerdictArtifact` (the skill's sanctioned interim) | type too small: 18–30% fill, Gate V fail | redrew the four cards in Manim with large type |
| The skill's LIAM LAW / `@NikBearBrown` outro | would credit a student assignment to someone else, and it's the kind of off-topic narration I asked to remove | no persona. Outro is a Manim title card with my name (same deviation as Sep 21) |
| Gates after the rewrite | Gate A (static outro), Gate B ×2 (overlaps), Gate V ×2 (contrast, fill), Gate T ×2 (terracotta text 2.74:1; a box read as a second label) | fixed each in the scene source. **No threshold relaxed**, `ART_STRICT` never lowered. Pass 9: Gate V clean, Gate T pass |
| Look for how the toolkit makes `FRICTIONAL.md` | nothing generates it, in `brutalist.art` or the course repo | this file, written from the logs plus my own answers |

- **Friction and response:** "the skill exists" and "the skill runs here" turned out to be two
  different claims. The first gate failure (25 MAJOR) was the toolkit's own component, not the
  script. The fix was to rebuild those beats rather than lower the bar.
- **Human and AI contributions:** Claude diagnosed each failure, wrote every fix, and ran the
  independent checks.
  - **Mine:** I didn't accept "no `cc-explainer` exists". I sent Claude to the upstream repo
    and ran the `git pull` myself. I asked for no persona and no off-topic content. I found the
    course rule that a toolkit failure is a legitimate Frictional entry, and asked for this
    entry to be written.
  - **What I agree with:** Claude rebuilt the terminal and cards instead of lowering the gate
    thresholds, and I agree with that; I wouldn't want to lower the quality bar just to make
    the toolkit work. I'd keep the correction beat, because Claude flipping my "correct" label
    to "wrong" was a useful mistake that shows the point of the experiment. And I wanted the
    final video to clearly be mine, so dropping the default persona and outro was right.
- **Still unresolved:** the `ShellSession` 4K scaling bug and the missing CC kit are toolkit
  issues. They were worked around in this reel, not fixed upstream.
- **Do I report them?** Yes. The workaround doesn't mean the underlying problem should be
  ignored. The fact that the skill exists upstream while some of its components can't run in the
  public repo is worth pointing out. I'll report it with the specific failures and the
  workaround I used, rather than just saying the toolkit is broken.
