"""
Manim scenes for cc-temperature-confident-not-correct.

B00/B01/B02/B04/B05/B06 TERMINAL  — the recorded session (SESSION.md), redrawn full-frame
BDEFS / BCONDUCT / BHUMAN / BVDT  — cards, full-frame
B03_Sweep               CONCEPT 1 — the three bars reshaping across T = 2, 1, 0.5
B07_ConfidentNotCorrect CONCEPT 2 — probability leaving the (made-up) correct answer
BOUT_TitleRestate       OUTRO     — title restate + author attribution (see BUILD-LOG.md)

Every number is copied from SESSION.md (turn 1 output, verify 2 output), which matches
learning-artifacts/ch01-temperature-ratio/run-output.json. Nothing here is illustrative.

AUDIO IS THE CLOCK. Each TARGET is the measured Kokoro duration (mp3/timings.json) plus a
short tail, so no scene is freeze-padded into a dead hold.
"""

from manim import *

# Claude fidelity palette — never retinted (tokens/claude.ts)
BG = "#FAF9F5"
INK = "#3D3929"
MUTED = "#6B6459"
TERRA = "#D97757"

SAFE_W = 6.1

# --- measured narration durations (mp3/timings.json) + tail ------------------
TARGET = {
    "B00": 14.2, "BDEFS": 16.7, "B01": 18.1, "B02": 16.4, "B03": 18.3,
    "B04": 17.8, "B05": 15.4, "B06": 17.1, "B07": 20.2,
    "BCONDUCT": 18.8, "BHUMAN": 15.9, "BVDT": 16.5, "BOUT": 3.9,
}

# --- recorded run (SESSION.md) ----------------------------------------------
PROBS = {
    2.0: [0.1863237232, 0.3071958857, 0.5064803911],
    1.0: [0.0900305732, 0.2447284711, 0.6652409558],
    0.5: [0.0158762400, 0.1173104278, 0.8668133322],
}
SWEEP = [2.0, 1.0, 0.5]


class Clock:
    """Audio-first pacing: every scene runs exactly as long as its narration."""

    def __init__(self, scene, target):
        self.s = scene
        self.target = target
        self.t = 0.0

    def play(self, *anims, run_time=1.0, **kw):
        self.s.play(*anims, run_time=run_time, **kw)
        self.t += run_time

    def wait(self, seconds):
        self.s.wait(seconds)
        self.t += seconds

    def finish(self, min_tail=0.4):
        self.s.wait(max(self.target - self.t, min_tail))


def txt(s, size, color=INK, max_w=None):
    """Text that never leaves the safe area: shrink to fit, never overflow."""
    t = Text(s, font_size=size, color=color)
    limit = max_w if max_w is not None else 2 * SAFE_W
    if t.width > limit:
        t.scale(limit / t.width)
    return t


def pct(p):
    return f"{p * 100:.1f}%"


class Bars:
    """Three bars on one baseline, re-shaped per temperature."""

    def __init__(self, c, colors, baseline=-1.25, max_h=3.0, bar_w=1.5, gap=1.1, label_size=34):
        self.c, self.baseline, self.max_h = c, baseline, max_h
        span = 3 * bar_w + 2 * gap
        left = -span / 2 + bar_w / 2
        self.xs = [left + i * (bar_w + gap) for i in range(3)]
        self.label_size = label_size
        self.bars = []
        for x, col in zip(self.xs, colors):
            b = Rectangle(width=bar_w, height=0.02, fill_color=col,
                          fill_opacity=0.92, stroke_width=0)
            b.move_to([x, baseline + 0.01, 0])
            self.bars.append(b)
            c.s.add(b)
        self.vals = None

    def h(self, p):
        return max(self.max_h * p, 0.02)

    def value_group(self, T):
        g = VGroup()
        for i, x in enumerate(self.xs):
            g.add(txt(pct(PROBS[T][i]), self.label_size, INK)
                  .move_to([x, self.baseline + self.h(PROBS[T][i]) + 0.32, 0]))
        return g

    def anims(self, T):
        return [b.animate.stretch_to_fit_height(self.h(PROBS[T][i]))
                .move_to([self.xs[i], self.baseline + self.h(PROBS[T][i]) / 2, 0])
                for i, b in enumerate(self.bars)]

    def show(self, T, run_time, extra=()):
        new_vals = self.value_group(T)
        if self.vals is None:
            self.c.play(*self.anims(T), *extra, run_time=run_time)
            self.vals = new_vals
            self.c.play(FadeIn(self.vals), run_time=0.4)
        else:
            self.c.play(*self.anims(T), Transform(self.vals, new_vals), *extra,
                        run_time=run_time)


def t_readout(T, y=2.45):
    return txt(f"temperature = {T:g}", 44, INK).move_to([0, y, 0])


# ------------------------------------------------------------ terminal ------
# The CC kit (CCSession) is not in the public toolkit, and ShellSession draws at
# 40% of a 4K frame. So the session is redrawn here, full-frame, large type.
# Every string below is copied from SESSION.md.

DARK = "#1F1E1B"      # CC.PAGE
PAPER = "#F2F0E9"     # CC.INK
DIM = "#A8A294"
BORDER = "#8A8478"
MONO = "Menlo"
T_SIZE = 26
CHAR_W = 0.2          # measured: Menlo @ 26 ≈ 0.2 units per character
X0 = -5.85
MAX_CHARS = 58
LINE_H = 0.5

PROMPT1 = ("Run probabilities() from lessons/01-randomness-and-first-prompts/code/main.py "
           "on scores [1, 2, 3] at temperatures 2, 1 and 0.5. Print each result. "
           "Don't edit any files.")
PROMPT2 = ("Say outcome 0 is the correct answer. I'm making that up, it's not measured. "
           "At each temperature, how much probability lands on outcome 0?")


def wrap(s, width, indent=""):
    words, lines, cur = s.split(" "), [], ""
    for w in words:
        cand = w if not cur else cur + " " + w
        limit = width if not lines else width - len(indent)
        if len(cand) <= limit:
            cur = cand
        else:
            if cur:
                lines.append(cur)
            while len(w) > limit:          # hard-wrap a long token (numbers, paths)
                lines.append(w[:limit]); w = w[limit:]
            cur = w
    if cur:
        lines.append(cur)
    return [l if i == 0 else indent + l for i, l in enumerate(lines)]


def mono(s, color=PAPER, size=T_SIZE):
    return Text(s, font=MONO, font_size=size, color=color)


class Term:
    """A full-frame Claude Code terminal. Lines land on narration cues."""

    def __init__(self, scene, target, title="claude — info-7375", k=1.0):
        self.k = k
        self.max_chars = int(11.8 / (CHAR_W * k))
        self.lh = LINE_H * k
        scene.camera.background_color = DARK
        self.s = scene
        self.c = Clock(scene, target)
        win = RoundedRectangle(width=12.3, height=6.5, corner_radius=0.18,
                               stroke_color=BORDER, stroke_width=3, fill_opacity=0)
        sep = Line([-6.15, 2.68, 0], [6.15, 2.68, 0], color=BORDER, stroke_width=2)
        dots = VGroup(*[Circle(radius=0.08, fill_color=col, fill_opacity=1, stroke_width=0)
                        .move_to([-5.8 + i * 0.3, 2.95, 0])
                        for i, col in enumerate(["#FF5F57", "#FEBC2E", "#28C840"])])
        head = mono(title, DIM, 22).move_to([0, 2.95, 0])
        scene.add(win, sep, dots, head)
        self.y = 2.3
        self.caret = Rectangle(width=0.16, height=0.32, fill_color=TERRA,
                               fill_opacity=0.9, stroke_width=0).set_opacity(0)
        self.caret.move_to([X0 + 0.08, self.y - 0.16, 0])
        scene.add(self.caret)

    def m(self, s, color=PAPER):
        return mono(s, color).scale(self.k)

    def at(self, t):
        self.c.wait(max(0.0, t - self.c.t))

    def _place(self, mob, x=X0):
        mob.align_to([x, 0, 0], LEFT)
        mob.move_to([mob.get_center()[0], self.y - self.lh / 2 + 0.05, 0])
        self.y -= self.lh
        return mob

    def _caret_to_end(self):
        if self.y < -2.75:                      # no room for a new prompt row
            return self.caret.animate.set_opacity(0)
        return self.caret.animate.move_to([X0 + 0.08, self.y - 0.16, 0]).set_opacity(0.9)

    def prompt(self, text, run_time=1.6):
        lines = wrap(text, self.max_chars - 2, indent="  ")
        self.c.play(self.caret.animate.set_opacity(0), run_time=0.1)   # no caret over the typing
        mobs = []
        for i, l in enumerate(lines):
            row = VGroup(self.m(">" if i == 0 else " ", TERRA), self.m(l.strip(), PAPER))
            row.arrange(RIGHT, buff=0.2, aligned_edge=DOWN)
            mobs.append(self._place(row))
        per = run_time / len(mobs)
        for m in mobs:
            self.c.play(AddTextLetterByLetter(m[1]), FadeIn(m[0]), run_time=per)
        self.c.play(self._caret_to_end(), run_time=0.2)

    def lines(self, rows, run_time=0.3, hi=False, indent="    "):
        """rows: list of (text, color). Wrapped; appear together."""
        group = VGroup()
        for text, color in rows:
            for l in wrap(text, self.max_chars, indent=indent):
                group.add(self._place(self.m(l, color)))
        anims = [FadeIn(group, shift=UP * 0.05), self._caret_to_end()]
        if hi:
            bar = Rectangle(width=0.08, height=group.height + 0.16, fill_color=TERRA,
                            fill_opacity=1, stroke_width=0)
            bar.next_to(group, LEFT, buff=0.1)
            anims += [FadeIn(bar)]
        self.c.play(*anims, run_time=run_time)
        return group

    def gap(self, h=0.18):
        self.y -= h

    def finish(self):
        self.c.finish()


class B00_ColdOpen(Scene):
    def construct(self):
        t = Term(self, TARGET["B00"], k=0.95)
        t.at(0.6)
        t.prompt(PROMPT1, run_time=3.2)          # typed while the question is asked
        t.gap()
        t.at(11.3)                               # "The first thing it does is read the file."
        t.lines([("● Let me read the file first to understand the function signature.", DIM)],
                indent="  ")
        t.gap()
        t.at(12.3)
        t.lines([("⏺ Read(lessons/01-randomness-and-first-prompts/code/main.py)", PAPER),
                 ("  ⎿  Read 33 lines", DIM)], hi=True, indent="  ")
        t.finish()


class B01_Tools(Scene):
    def construct(self):
        t = Term(self, TARGET["B01"], k=0.95)
        t.at(0.3)
        t.lines([("⏺ Bash(python3 -c \"from lessons.01-randomness-and-first-prompts"
                  ".code.main import …\" || python3 -c \"…\")", PAPER)], indent="  ")
        t.at(1.6)
        t.lines([("  ⎿  SyntaxError: invalid syntax", TERRA)], hi=True)   # "…fails"
        t.gap()
        t.at(6.1)                                # "It had a backup command ready"
        t.lines([("     temperature=2: [0.1863237232258476, 0.3071958857184984, "
                  "0.506480391055654]", PAPER)], indent="       ")
        t.at(7.0)
        t.lines([("     temperature=1: [0.09003057317038046, 0.24472847105479764, "
                  "0.6652409557748218]", PAPER)], indent="       ")
        t.at(7.9)
        t.lines([("     temperature=0.5: [0.015876239976466765, 0.11731042782619838, "
                  "0.8668133321973349]", PAPER)], indent="       ")
        t.at(14.5)                               # "about fifty one … eighty seven"
        t.lines([("# top answer: 0.5065 → 0.6652 → 0.8668", TERRA)], indent="  ")
        t.finish()


class B02_Verify(Scene):
    def construct(self):
        t = Term(self, TARGET["B02"], title="zsh — info-7375  (my check)")
        t.at(4.0)                                # "So I run my own check."
        t.prompt("bash session/verify1.sh", run_time=0.8)
        t.gap()
        t.at(5.5)
        t.lines([("# for each temperature: do the chances add up to 1?", DIM),
                 ("# and which outcome is on top?", DIM)], indent="  ")
        t.gap()
        t.at(9.6)                                # "Every row adds up to one."
        t.lines([("2    sum = 1.0   top = 2", PAPER),
                 ("1    sum = 1.0   top = 2", PAPER),
                 ("0.5  sum = 1.0   top = 2", PAPER)], hi=True, indent="")
        t.gap()
        t.at(13.8)                               # "Temperature didn't change the winner."
        t.lines([("# the winner never changed", TERRA)], indent="  ")
        t.finish()


class B04_Prompt2(Scene):
    def construct(self):
        t = Term(self, TARGET["B04"])
        t.at(2.7)                                # "so I give it one"
        t.prompt(PROMPT2, run_time=3.0)
        t.gap()
        t.at(9.3)                                # "Claude answers … without running anything"
        t.lines([("# no tools run — it answered from the last table", DIM)], indent="  ")
        t.gap()
        t.at(12.5)
        t.lines([("| Temperature | P(outcome 0) |", DIM)], indent="")
        t.at(14.4)
        t.lines([("| 2.0         | 0.18632      |", PAPER),
                 ("| 1.0         | 0.09003      |", PAPER),
                 ("| 0.5         | 0.01588      |", PAPER)], hi=True, indent="")
        t.finish()


class B05_Catch(Scene):
    def construct(self):
        t = Term(self, TARGET["B05"])
        self.add(t._place(t.m("> Say outcome 0 is the correct answer. I'm making that up…", DIM)))
        self.add(t._place(t.m("| 2.0  0.18632 | 1.0  0.09003 | 0.5  0.01588 |", DIM)))
        t.gap()
        t.at(0.4)                                # "read the sentence under the table"
        t.lines([("Higher temperature spreads probability more evenly, so the", PAPER)],
                indent="")
        t.at(3.9)                                # "Claude calls it the wrong answer."
        t.lines([("\"wrong\" answer (logit=1, the lowest)", PAPER)], hi=True, indent="")
        t.at(4.6)
        t.lines([("actually gets more probability mass at T=2 than at T=1 or", PAPER),
                 ("T=0.5. Cooling the model makes it more confident — but", PAPER),
                 ("confident in the direction the logits point, not in the", PAPER),
                 ("ground truth.", PAPER)], indent="")
        t.gap()
        t.at(6.2)                                # "the label flipped"
        t.lines([("# I said outcome 0 is CORRECT. The label flipped.", TERRA)], indent="  ")
        t.finish()


class B06_Verify2(Scene):
    def construct(self):
        t = Term(self, TARGET["B06"], title="zsh — info-7375  (my check)", k=0.9)
        t.at(0.3)
        t.prompt("python3 learning-artifacts/ch01-temperature-ratio/temperature_ratio.py "
                 "| grep -E '\"temperature\"|correct_label'", run_time=1.6)
        t.gap()
        t.at(6.6)                                # "At temperature two …"
        t.lines([('"temperature": 2.0,', DIM),
                 ('"probability_on_constructed_correct_label": 0.1863237232', PAPER)],
                indent="")
        t.at(10.3)                               # "At one …"
        t.lines([('"temperature": 1.0,', DIM),
                 ('"probability_on_constructed_correct_label": 0.0900305732', PAPER)],
                indent="")
        t.at(11.6)                               # "At one half …"
        t.lines([('"temperature": 0.5,', DIM),
                 ('"probability_on_constructed_correct_label": 0.01587624', PAPER)],
                hi=True, indent="")
        t.gap()
        t.at(13.5)                               # "calls it the correct label"
        t.lines([("# same numbers — and it says CORRECT label", TERRA)], indent="  ")
        t.finish()


# --------------------------------------------------------------- cards ------
def marker(y, h=0.7, color=TERRA):
    return Rectangle(width=0.09, height=h, fill_color=color, fill_opacity=1,
                     stroke_width=0).move_to([-6.18, y, 0])


def card_title(s):
    return txt(s, 50, INK, max_w=11.4).move_to([0, 3.0, 0])


def footer():
    """Full-width base rule: the card's frame, present from the first frame."""
    return Line([-6.1, -3.1, 0], [6.1, -3.1, 0], color=MUTED, stroke_width=2)


class BDEFS_Terms(Scene):
    def construct(self):
        self.camera.background_color = BG
        c = Clock(self, TARGET["BDEFS"])
        title = card_title("Four words you'll hear")
        self.add(footer())
        rule = Line([-1.6, 2.52, 0], [1.6, 2.52, 0], color=TERRA, stroke_width=4)
        self.add(title)
        c.play(Create(rule), run_time=0.5)
        rows = [("Score", "how much the model likes each answer, before any math", 1.4),
                ("Temperature", "one number that makes the choice sharper or flatter", 4.7),
                ("Probability", "each answer's share of the chances — they add up to 1", 8.0),
                ("Answer key", "which answer is actually right. Here, I made it up.", 11.8)]
        for i, (term, meaning, cue) in enumerate(rows):
            y = 1.62 - i * 1.3
            c.wait(max(0.0, cue - c.t))
            left = txt(term, 40, INK)
            left.align_to([-6.0, 0, 0], LEFT).move_to([left.get_center()[0], y, 0])
            words = meaning.split(" ")
            half = (len(words) + 1) // 2
            right = VGroup(txt(" ".join(words[:half]), 32, INK, max_w=8.0),
                           txt(" ".join(words[half:]), 32, INK, max_w=8.0))
            right.arrange(DOWN, aligned_edge=LEFT, buff=0.12)
            right.align_to([-2.2, 0, 0], LEFT).move_to([right.get_center()[0], y, 0])
            c.play(FadeIn(left, shift=RIGHT * 0.1), FadeIn(right), FadeIn(marker(y, 0.95)),
                   run_time=0.5)
        c.finish()


class BCONDUCT_WhoDidWhat(Scene):
    def construct(self):
        self.camera.background_color = BG
        c = Clock(self, TARGET["BCONDUCT"])
        self.add(card_title("Who did what"), footer())
        rows = [("YOU", "asked: does cooler mean more correct?", 1.2),
                ("CLAUDE", "ran the lesson code  →  check: every row adds to 1", 2.4),
                ("YOU", "checked it myself — the winner never moved", 5.9),
                ("CLAUDE", "answered from the old table  →  check: keep my key", 7.1),
                ("YOU", "caught \"wrong\" where I said correct", 14.2),
                ("YOU", "re-ran my own script — that is the evidence", 16.4)]
        ys = [2.1 - i * 0.92 for i in range(len(rows))]
        for (who, what, cue), y in zip(rows, ys):
            c.wait(max(0.0, cue - c.t))
            tag = txt(who, 30, INK if who == "YOU" else MUTED)
            tag.align_to([-6.0, 0, 0], LEFT).move_to([tag.get_center()[0], y, 0])
            body = txt(what, 32, INK, max_w=9.4)
            body.align_to([-3.6, 0, 0], LEFT).move_to([body.get_center()[0], y, 0])
            c.play(FadeIn(tag), FadeIn(body, shift=RIGHT * 0.1),
                   FadeIn(marker(y, 0.5, TERRA if who == "YOU" else MUTED)), run_time=0.45)
            if who == "CLAUDE" and "old table" in what:
                c.wait(max(0.0, 12.7 - c.t))     # "That's the risky middle."
                ring = Rectangle(width=12.3, height=0.74, color=TERRA, stroke_width=4,
                                 fill_opacity=0).move_to([0, y, 0])
                c.play(Create(ring), run_time=0.7)
        c.finish()


class BHUMAN_Ledger(Scene):
    def construct(self):
        self.camera.background_color = BG
        c = Clock(self, TARGET["BHUMAN"])
        self.add(card_title("Whose job is it?"), footer())
        divider = Line([0, 2.2, 0], [0, -1.6, 0], color=MUTED, stroke_width=2)
        c.play(Create(divider), run_time=0.5)
        lh = txt("YOU MUST", 36, INK).move_to([-3.1, 1.85, 0])
        rh = txt("CLAUDE CAN", 36, MUTED).move_to([3.1, 1.85, 0])
        c.wait(max(0.0, 1.9 - c.t))
        c.play(FadeIn(lh), run_time=0.3)
        l1 = txt("decide which answer", 32, INK).move_to([-3.1, 0.95, 0])
        l1b = txt("is correct", 32, INK).move_to([-3.1, 0.45, 0])
        c.play(FadeIn(l1), FadeIn(l1b), run_time=0.4)
        c.wait(max(0.0, 6.4 - c.t))
        l2 = txt("run the check myself", 32, INK).move_to([-3.1, -0.55, 0])
        c.play(FadeIn(l2), FadeIn(Rectangle(width=4.6, height=0.05, fill_color=TERRA,
               fill_opacity=1, stroke_width=0).move_to([-3.1, -0.95, 0])), run_time=0.4)
        c.wait(max(0.0, 8.3 - c.t))
        c.play(FadeIn(rh), run_time=0.3)
        r1 = txt("run the code in seconds", 32, INK).move_to([3.1, 0.7, 0])
        r2 = txt("make a clean table", 32, INK).move_to([3.1, -0.55, 0])
        c.play(FadeIn(r1), run_time=0.4)
        c.play(FadeIn(r2), run_time=0.4)
        c.wait(max(0.0, 12.3 - c.t))
        close = txt("Next time I won't hand off: the answer key.", 36, INK, max_w=11.0)
        close.move_to([0, -2.55, 0])
        box = Rectangle(width=close.width + 0.5, height=close.height + 0.4, color=TERRA,
                        stroke_width=4, fill_opacity=0).move_to(close.get_center())
        c.play(FadeIn(close), Create(box), run_time=0.7)
        c.finish()


class BVDT_Verdict(Scene):
    def construct(self):
        self.camera.background_color = BG
        c = Clock(self, TARGET["BVDT"])
        title = card_title("Confident, not correct")
        self.add(footer())
        rule = Line([-1.8, 2.52, 0], [1.8, 2.52, 0], color=TERRA, stroke_width=4)
        self.add(title)
        c.play(Create(rule), run_time=0.5)
        rows = [("1", "Temperature changes how sure the model is.", 0.9),
                ("2", "It never changes which answer is on top.", 3.3),
                ("3", "At 0.5, 87% sat on an answer my key calls wrong.", 5.5),
                ("4", "Test it: if the top answer ever changes, this is wrong.", 9.9)]
        last = None
        for i, (n, line, cue) in enumerate(rows):
            y = 1.55 - i * 1.15
            c.wait(max(0.0, cue - c.t))
            num = txt(n, 38, INK).move_to([-5.7, y, 0])
            body = txt(line, 36, INK, max_w=10.6)
            body.align_to([-5.1, 0, 0], LEFT).move_to([body.get_center()[0], y, 0])
            c.play(FadeIn(num), FadeIn(body, shift=RIGHT * 0.1), FadeIn(marker(y, 0.6)),
                   run_time=0.45)
            last = VGroup(num, body)
        box = Rectangle(width=12.0, height=last.height + 0.45, color=TERRA,
                        stroke_width=4, fill_opacity=0).move_to([0, last.get_center()[1], 0])
        c.play(Create(box), run_time=0.7)
        c.finish()


# ---------------------------------------------------------------- B03 -------
class B03_Sweep(Scene):
    def construct(self):
        self.camera.background_color = BG
        c = Clock(self, TARGET["B03"])

        title = txt("Same scores: 1, 2, 3", 48, INK, max_w=11.4).move_to([0, 3.02, 0])
        self.add(title, footer())

        bars = Bars(c, [MUTED, MUTED, TERRA])
        self.add(Line([-5.6, bars.baseline, 0], [5.6, bars.baseline, 0],
                      color=MUTED, stroke_width=2))
        for i, x in enumerate(bars.xs):
            self.add(txt(f"outcome {i}", 32, INK).move_to([x, bars.baseline - 0.42, 0]))

        readout = t_readout(2.0)
        c.wait(2.6)
        c.play(FadeIn(readout), run_time=0.4)
        bars.show(2.0, 1.0)                     # "At temperature two … spread out"
        c.wait(1.4)

        def restate(T, run_time):
            bars.show(T, run_time, extra=[Transform(readout, t_readout(T))])

        restate(1.0, 1.0)                       # "At one, they lean harder"
        c.wait(1.4)
        restate(0.5, 1.0)                       # "At one half … almost all of it"
        c.wait(1.2)

        lane_h = bars.h(PROBS[0.5][2]) + 0.72
        lane = Rectangle(width=2.0, height=lane_h, color=TERRA,
                         stroke_width=4, fill_opacity=0)
        lane.move_to([bars.xs[2], bars.baseline + lane_h / 2, 0])
        note = txt("the order never changes", 36, INK).move_to([0, -2.55, 0])
        c.play(Create(lane), FadeIn(note), run_time=0.8)   # "Now watch the order"

        for T in SWEEP:                          # the claim, shown again
            restate(T, 0.7)
        c.wait(0.6)

        final = txt("temperature sets how hard it leans — not who wins",
                    34, INK, max_w=11.0).move_to([0, -2.55, 0])
        c.play(Transform(note, final), run_time=0.8)
        c.finish()


# ---------------------------------------------------------------- B07 -------
class B07_ConfidentNotCorrect(Scene):
    def construct(self):
        self.camera.background_color = BG
        c = Clock(self, TARGET["B07"])

        title = txt("Confident, not correct", 50, INK).move_to([0, 3.02, 0])
        self.add(title)

        bars = Bars(c, [TERRA, MUTED, MUTED], baseline=-1.15, max_h=2.9)
        self.add(Line([-5.6, bars.baseline, 0], [5.6, bars.baseline, 0],
                      color=MUTED, stroke_width=2))
        tags = ["correct (my key)", "wrong", "wrong"]
        for i, x in enumerate(bars.xs):
            self.add(txt(f"outcome {i}", 32, INK).move_to([x, bars.baseline - 0.40, 0]))
            self.add(txt(tags[i], 28, INK if i == 0 else MUTED, max_w=2.5)
                     .move_to([x, bars.baseline - 0.85, 0]))

        readout = t_readout(2.0, y=2.45)
        c.wait(0.6)
        c.play(FadeIn(readout), run_time=0.4)
        bars.show(2.0, 1.0)

        key = txt("I made the key up: outcome 0 is correct", 30, INK, max_w=10.0)
        key.move_to([0, -2.72, 0])
        box = Line(key.get_corner(DL) + DOWN * 0.14, key.get_corner(DR) + DOWN * 0.14,
                   color=TERRA, stroke_width=4)
        c.play(FadeIn(key), Create(box), run_time=0.8)   # "my key calls correct"
        c.wait(2.0)

        def restate(T, run_time):
            bars.show(T, run_time, extra=[Transform(readout, t_readout(T, y=2.45))])

        restate(1.0, 1.2)                        # "its share shrinks … to nine"
        c.wait(1.2)
        restate(0.5, 1.2)                        # "… to under two"
        c.wait(1.6)

        c.play(Indicate(bars.vals[2], color=INK, scale_factor=1.35), run_time=0.8)       # "eighty seven percent piles onto outcome two"
        c.wait(3.4)

        punch = txt("more confident — not more correct", 38, INK, max_w=10.4)
        punch.move_to([0, -2.72, 0])
        c.play(FadeOut(box), Transform(key, punch), run_time=0.8)   # "Nothing broke …"
        c.finish()


# ---------------------------------------------------------------- BOUT ------
class BOUT_TitleRestate(Scene):
    def construct(self):
        self.camera.background_color = BG
        c = Clock(self, TARGET["BOUT"])

        kicker = txt("RANDOMNESS AND FIRST PROMPTS  ·  INFO 7375", 30, MUTED,
                     max_w=10.0).move_to([0, 2.75, 0])
        line1 = txt("Temperature makes answers", 74, INK, max_w=12.0).move_to([0, 1.45, 0])
        line2 = txt("confident, not correct", 74, INK, max_w=12.0).move_to([0, 0.35, 0])
        dot = txt(".", 74, INK).next_to(line2, RIGHT, buff=0.04)
        self.add(kicker)

        c.play(FadeIn(line1, shift=UP * 0.1), run_time=0.5)
        c.play(FadeIn(line2, shift=UP * 0.1), FadeIn(dot), run_time=0.5)

        rule = Line([-1.2, -0.75, 0], [1.2, -0.75, 0], color=TERRA, stroke_width=6)
        wide = Line([-4.0, -0.75, 0], [4.0, -0.75, 0], color=TERRA, stroke_width=6)
        who = txt("Smit Patel", 48, INK).move_to([0, -1.65, 0])
        course = txt("INFO 7375  ·  Prompt Engineering for Generative AI", 32, MUTED,
                     max_w=11.0).move_to([0, -2.65, 0])
        hairline = Line([-4.4, -2.15, 0], [4.4, -2.15, 0], color=MUTED, stroke_width=2)
        c.play(Create(rule), run_time=0.3)
        c.play(Transform(rule, wide), FadeIn(who), run_time=0.5)
        c.play(Create(hairline), FadeIn(course), run_time=0.4)
        c.finish()
