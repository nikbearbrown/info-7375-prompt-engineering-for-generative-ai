# Temperature Makes Answers Confident, Not Correct

**Author:** Smit Patel
**Course:** INFO 7375 — Prompt Engineering for Generative AI, Week 1
**Concept:** Chapter 1, *Randomness and first prompts*: turning temperature down makes a model's
answer more *confident* (more probability on its favourite), not more *correct*.
**Why this concept:** it is the easiest temperature mistake to make, and three numbers are
enough to watch confident and correct split apart.
**Builder:** `brutalist.art` `cc-explainer` (16:9), free local pipeline
**Runtime:** ~3 min 56 s (235.9 s of narration)
**Final file:** `final/cc-temperature-confident-not-correct.mp4`

## What the video shows

A real Claude Code session (2026-09-25), two turns:

1. Claude runs the lesson's `probabilities()` on scores `[1, 2, 3]` at temperatures 2, 1, 0.5.
   The top answer's share grows 50.6% → 66.5% → 86.7%. I check it myself: every row sums to 1,
   and the top answer never changes.
2. I say outcome 0 is the correct answer (made up by me). Its share shrinks 18.6% → 9.0% → 1.6%.
   Claude gets the numbers right but calls outcome 0 the *"wrong"* answer. I catch it and re-run
   my own script, which agrees on the numbers and keeps the label.

Lower temperature piled 87% onto an answer my key calls wrong: more confident, not more correct.

## Rebuild

See `BUILD-PROMPT.md`. In short, from a `brutalist.art` checkout at `6a8380a`:

```bash
python3 runtime/scripts/generate_audio_kokoro.py "$REEL"
./art run   "$REEL" --height 1080
./art final "$REEL" --height 1080 --out "$REEL/final"
```

## Files

| File | What it holds |
|---|---|
| `final/cc-temperature-confident-not-correct.mp4` | the rendered video, 1920×1080, 236 s |
| `beat_sheet.json` | the reviewed narration and visual plan, 15 beats |
| `scenes.py` | Manim source for 13 of the 15 beats (needed to rebuild) |
| `BUILD-PROMPT.md` | the prompts and commands that rebuild it |
| `SOURCES.md` | what I used, what I made, what Claude contributed, licences |
| `FRICTIONAL.md` | dated log of attempts, friction, contributions, learning |

Supporting evidence cited in `FRICTIONAL.md` and `SOURCES.md` (`SESSION.md`, `BUILD-LOG.md`,
`FACTCHECK.md`, `CHECKS-REPORT.md`, the verify script) is kept in my working folder and
available on request.
