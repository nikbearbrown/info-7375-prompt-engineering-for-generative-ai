# SOURCES — cc-temperature-confident-not-correct

## What I used

| Item | Where | Licence / owner |
|---|---|---|
| Course reference implementation `probabilities()` | `lessons/01-randomness-and-first-prompts/code/main.py` | INFO 7375 course repo |
| Toolkit: `cc-explainer` skill, scenes, render gates | `brutalist.art` @ `6a8380a` (github.com/nikbearbrown/brutalist.art) | no LICENSE file in the repo; used as the course's instructor-provided toolkit |
| Manim Community v0.18.1 (all beats except BIDEA, BHTF) | pip | MIT |
| Remotion (BIDEA, BHTF) | toolkit `node_modules` | Remotion Free License (individuals, free) |
| `BrutalistHesitantWriter` (BIDEA) | toolkit; rewrite of a base44 canvas component | original author unknown, per the component's own header; credit unresolved in the toolkit |
| Narration voice | Kokoro-82M via `kokoro-onnx` 0.6.1, voice `am_onyx`, run locally | Apache-2.0 (model) |
| Fonts | EB Garamond (BIDEA, via toolkit `runtime/fonts`); Menlo and the system serif (Manim, macOS system fonts) | EB Garamond: SIL OFL; Menlo / system fonts: Apple, used locally |
| Palette | toolkit Claude tokens (`tokens/claude.ts`) | toolkit |

**Synthetic narration disclosure:** every word of narration is a synthetic voice (Kokoro
`am_onyx`) reading a script. The narration does not say so, by the author's choice to keep the
video on topic. This file is the disclosure.

## What I made

- The question, and the made-up answer key (outcome 0 is "correct").
- `learning-artifacts/ch01-temperature-ratio/temperature_ratio.py` (Week 1, 2026-09-21), used as
  the second VERIFY step.
- `session/verify1.sh`, the first VERIFY step.
- The review of the session: noticing that Claude called the "correct" outcome "wrong".

## What Claude contributed

- **In the video (Claude Code, 2026-09-25):** the two recorded turns in `SESSION.md`: it read
  `main.py`, ran it (after a failed first import), made the tables, and wrote the sentence that
  mislabels outcome 0. Shown verbatim.
- **In building the video:** Claude (in Claude Code) ran that session on my behalf from my
  prompts, drafted the beat sheet, narration, Manim scenes and this paperwork, and drove the
  render. I reviewed the result.

## Doctrine for the closing beats

- CONDUCT (who did what, handoff conditions, the capacity labels PF / PA / IJ): the
  `info-7375-conducting-ai` material, via `skills/make/cc-explainer/reference/three-beats.md`.
- HUMAN (MUST / SHOULD / CAN ledger): `info-7375-irreducibly-human`, via the same file.

No third-party images, music or video clips are used.
