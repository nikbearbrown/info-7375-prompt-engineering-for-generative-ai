# BUILD-PROMPT — cc-temperature-confident-not-correct

The instruction this video was built from, and everything needed to rebuild it.

## The ask

```text
Rebuild my Week 1 video (assignment-01-temperature-ratio-smit-patel, a cli-explainer reel)
as a cc-explainer video. Same concept: temperature concentrates a distribution; it does not
make the answer more correct. Make it much simpler and easier to understand. Remove anything
that is not about the topic (who the voice is, how it was made).
```

## Rules applied

- `skills/make/cc-explainer/SKILL.md` spine: cold open in the terminal → THE IDEA → DEFINITIONS →
  cycle 1 (prompt, tools, verify) → cycle 2, the correction (prompt, catch, verify) → CONDUCT →
  HUMAN → VERDICT → YOUR TURN → OUTRO. Concept film, so BUILD-SHOW is not armed.
- REAL-SESSION LAW: a real Claude Code session was run first and saved as `SESSION.md`.
- Every VERIFY is my own command, not Claude's ✓.
- No persona intro, no voice or tooling talk in the narration; disclosures live in `SOURCES.md`.

## Step 1 — the session (already recorded; re-run to reproduce)

From the course repo root:

```bash
claude -p "Run probabilities() from lessons/01-randomness-and-first-prompts/code/main.py on scores [1, 2, 3] at temperatures 2, 1 and 0.5. Print each result. Don't edit any files." --allowedTools "Read" "Bash(python3:*)" --output-format stream-json --verbose > cycle1.jsonl
claude -p "Say outcome 0 is the correct answer. I'm making that up, it's not measured. At each temperature, how much probability lands on outcome 0?" --resume <session-id-from-cycle1> --allowedTools "Read" "Bash(python3:*)" --output-format stream-json --verbose > cycle2.jsonl
python3 -c "import sys; sys.path.insert(0,'lessons/01-randomness-and-first-prompts/code'); from main import probabilities; [print(t,'sum =',round(sum(p:=probabilities([1,2,3],t)),12),' top =',p.index(max(p))) for t in [2,1,0.5]]"
python3 learning-artifacts/ch01-temperature-ratio/temperature_ratio.py | grep -E '"temperature"|correct_label'
```

A new session will not produce the same wording, so the beats would need re-checking against a
new `SESSION.md`. The numbers are deterministic.

## Step 2 — the video

```bash
REEL="$(pwd)"                        # this folder
cd /path/to/brutalist.art            # revision 6a8380a
python3 runtime/scripts/generate_audio_kokoro.py "$REEL"   # audio = the clock
./art run   "$REEL" --height 1080                          # gates + render + review cut
./art final "$REEL" --height 1080 --out "$REEL/final"
```

If narration changes, re-run the audio, then copy the new durations from `mp3/timings.json`
into the `TARGET` table at the top of `scenes.py` before `./art run`.
